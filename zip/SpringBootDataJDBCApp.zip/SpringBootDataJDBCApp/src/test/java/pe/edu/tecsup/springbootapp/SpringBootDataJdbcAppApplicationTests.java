package pe.edu.tecsup.springbootapp;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class SpringBootDataJdbcAppApplicationTests {

	@Test
	void contextLoads() {
	}

}
